package com.cg.client;
import java.util.Scanner;

import com.cg.Exception.UASException;

public class MainClass {

	public static void main(String[] args) {
		int choice=-1;
		Scanner scan = new Scanner(System.in);
		while (true) {
			
			
				System.out.println("\n\n**************************************************");
				System.out.println("Welcome to University Admission System");
				System.out.println("\n**************************************************");
				System.out.println("\nEnter an option:");
				System.out.println("\t1. New Applicant\n\t"
						+ "2. Member Login");
				System.out.println("\n**************************************************");
				System.out.println("Enter 0 to Exit");
				System.out.println("Enter your choice:");
				choice = scan.nextInt();
			
			switch (choice) {
			
				case 1:
						System.out.println("*******************Accessing Portal as a New Applicant******************\n");
						ApplicantMain applicant=new ApplicantMain();
				try {
					applicant.NewApplication();
				} catch (UASException e1) {
					// TODO Auto-generated catch block
					System.out.println(e1.getMessage());
				}
						break;
				case 2:
						MemberLoginMain memlog=new MemberLoginMain();
						System.out.println("Getting you to Login Page");
						try {
							memlog.Login();
						} catch (UASException e) {
							System.out.println(e.getMessage());
						}
						break;
				case 0:
						System.out.println("Thank you! Exiting from Application...\n");
						scan.close();
						System.exit(0);
						break;
				default:
						System.err.println("You have selected an Invalid option. "
								+ "Please try again\n");
						break;
			}
		}
	}
}
