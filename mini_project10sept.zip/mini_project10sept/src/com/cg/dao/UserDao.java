package com.cg.dao;

import com.cg.Exception.UASException;

public interface UserDao {
	public String ReturnRole(String loginId, String password) throws UASException;
}
