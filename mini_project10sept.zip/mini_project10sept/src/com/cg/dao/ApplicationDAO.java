package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.Exception.UASException;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;


public interface ApplicationDAO {
	
	int addApplication(Application applicant) throws UASException;
	String applicationStatus(int ID) throws UASException;
	ArrayList <ProgramScheduled> getAllScheduledPrograms() throws UASException;
	public ArrayList<String> getScheduledProgramId() throws UASException;
}
