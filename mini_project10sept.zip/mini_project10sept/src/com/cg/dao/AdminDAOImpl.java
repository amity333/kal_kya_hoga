package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.Exception.UASException;
import com.cg.QMapper.AdminQMapper;
import com.cg.dto.Application;
import com.cg.dto.ProgramOffered;
import com.cg.dto.ProgramScheduled;
import com.cg.util.DBUtil;
import com.cg.util.MyStringDateUtil;

public class AdminDAOImpl implements AdminDAO {
	
	Connection con =null;	

	public AdminDAOImpl() throws IOException {
		super();
		con = DBUtil.getConnection() ;
	}

	@Override
	public boolean checkLogin(String loginId, String password) {
		boolean check = false;
		try{
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(AdminQMapper.DETAILS_usingROLE);
			while(rs.next()){
				if(loginId.equals(rs.getString(1)) && password.equals(rs.getString(2))){
					check = true;
					break;
				}
			}
		}
		catch(Exception e){
			System.out.println("Something went Wrong");
			System.out.println(e.getMessage());
		}
		return check;
	}

	@Override
	
	public void addProgram(ProgramOffered obj) throws UASException {
		try{
			PreparedStatement pst = con.prepareStatement(AdminQMapper.INSERT_PO);
			pst.setString(1, obj.getProgramName());
			pst.setString(2, obj.getDescription());
			pst.setString(3, obj.getApplicantEligibility());
			pst.setInt(4, obj.getDuration());
			pst.setString(5, obj.getDegreeCertificateOffered());
			pst.execute();
		}
		catch(Exception e){
			
			throw new UASException(e.getMessage());
		}
	}

	@Override
	public boolean deleteProgram(String programName) throws UASException {
		try{
			PreparedStatement pst = con.prepareStatement(AdminQMapper.DELETE_PS);
			pst.setString(1, programName);
			pst.execute();
			return true;
		}
		catch(Exception e){			
			throw new UASException("Program already has applicants.");
		}
	}


	@Override
	public void scheduleProgram(ProgramScheduled obj) {
		try{
			PreparedStatement pst = con.prepareStatement(AdminQMapper.INSERT_PS);
			pst.setString(1, obj.getScheduledProgramId());
			pst.setString(2, obj.getProgramName());
			pst.setString(3, obj.getLocation());
			pst.setDate(4, obj.getStartDate());
			pst.setDate(5, obj.getEndDate());
			pst.setInt(6, obj.getSessionsPerWeek());
			pst.execute();
		}
		catch(Exception e){
			System.out.println("Program does not get Scheduled");
			System.out.println(e.getMessage());
		}
	}


	@Override
	public ArrayList<ProgramScheduled> getScheduledProgram(Date startDate, Date endDate) {
		ArrayList<ProgramScheduled> list = new ArrayList<ProgramScheduled>();
		try{
			PreparedStatement pst = con.prepareStatement(AdminQMapper.GET_SCH_PROGRAM);			
			pst.setDate(1, startDate);
			pst.setDate(2, endDate);
			ResultSet rs = pst.executeQuery();
			while(rs.next()){
				list.add(new ProgramScheduled(rs.getString(1) , rs.getString(2), rs.getString(3), rs.getDate(4), rs.getDate(5), rs.getInt(6)));
			}
		}
		catch(Exception e){
			System.out.println("scheduled program problem");
			System.out.println(e.getMessage());
		}		
		return list;
	}

	@Override
	public ArrayList<Application> getStatus(String status) {
		ArrayList<Application> list = new ArrayList<Application>();
		try{
			System.out.println(status);
			PreparedStatement pst = con.prepareStatement(AdminQMapper.APPLICANT_BY_STATUS);
			pst.setString(1, status);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				if(rs.getDate(10)==null)
				{
					Application ps = new Application(rs.getInt(1), rs.getString(2), MyStringDateUtil.fromSqlToLocalDate(rs.getDate(3)), rs.getString(4), rs.getInt(5), rs.getString(6), rs.getString(7),rs.getString(8), rs.getString(9));
					list.add(ps);
				}
				else
				{
				Application ps = new Application(rs.getInt(1), rs.getString(2), rs.getDate(3), rs.getString(4), rs.getInt(5), rs.getString(6), rs.getString(7),rs.getString(8), rs.getString(9), rs.getDate(10));
				list.add(ps);
				}
			}	
		}		
		catch(Exception e){
			System.out.println("No Aplication could be found");
			System.out.println(e.getMessage());
		}		
		return list;
	}

	@Override
	public ArrayList<String> getProgramsOffered() {
		ArrayList<String> list = new ArrayList<String>();
		try{
			PreparedStatement pst = con.prepareStatement(AdminQMapper.PROGRAMNAME_fromPO);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
			list.add(rs.getString(1));
			}	
		}		
		catch(Exception e){
			System.out.println("No Programs Found");
			System.out.println(e.getMessage());
		}
		return list;
	}

	@Override
	public ArrayList<ProgramOffered> getProgramsOfferedDetails() throws UASException {
		ArrayList<ProgramOffered> list = new ArrayList<ProgramOffered>();
		try {
			PreparedStatement pst = con.prepareStatement(AdminQMapper.GET_PROG_OFFERED);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				list.add(new ProgramOffered(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5)));
			}	
		}catch(Exception e) {
			throw new UASException(e.getMessage());
		}
		return list;
	}
}