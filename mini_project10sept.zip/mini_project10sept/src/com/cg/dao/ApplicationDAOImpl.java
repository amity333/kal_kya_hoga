package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.Exception.UASException;
import com.cg.QMapper.ApplicationQMapper;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;
import com.cg.util.DBUtil;
import com.cg.util.LoggerClass;
import com.cg.util.MyStringDateUtil;

public class ApplicationDAOImpl implements ApplicationDAO{
	
	Connection con=null;
	Logger logger=null;

	public ApplicationDAOImpl() {
		logger = LoggerClass.getLogger(this.getClass());
		}

	/*******************************************************************************************************
	 - Function Name	:	addApplication()
	 - Input Parameters	:	Applicant
	 - Return Type		:	Integer
	 - Author			:	CAPGEMINI
	 - Creation Date	:	12/09/2019
	 - Description		:	adding applicant details to database
	 * @throws UASException 
	 ********************************************************************************************************/
	@Override
	public int addApplication(Application applicant) throws UASException {
		int applicationId = 0;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		PreparedStatement appIdStatement = null;
		
		if (applicant != null) {
			
			try {
				logger.info("Inserting applicant details stated ");
				java.sql.Date sqlDOB = MyStringDateUtil.fromLocalToSqlDate(applicant.getDateOfBirth());
				con= DBUtil.getConnection();
				logger.info("Connection established to the Database");
				pstmt = con.prepareStatement(ApplicationQMapper.INSERT);
				pstmt.setString(1, applicant.getFullName());
				pstmt.setDate(2, sqlDOB);
				pstmt.setString(3, applicant.getHighestQualification());
				pstmt.setInt(4, applicant.getMarksObtained());
				pstmt.setString(5, applicant.getGoals());
				pstmt.setString(6, applicant.getEmailId());
				pstmt.setString(7, applicant.getScheduledProgramId());
				int count = pstmt.executeUpdate();
				if (count > 0){
					appIdStatement = con.prepareStatement(ApplicationQMapper.CURR_APP_ID);
					rs=appIdStatement.executeQuery();
					if(rs.next())
					{
						applicationId=rs.getInt(1);
						System.out.println("Applicant Id is: "+applicationId);
					}
					logger.info("Inserting applicant details successful ");
				}
				else {				
					System.out.println("Insertion of applicant details failed ");
					logger.fatal("Insertion of applicant details failed ");
				}				
			}
			catch (SQLException | IOException e) 
			{
				logger.fatal("Exception occured while inserting application ");
				throw new UASException("Exception occured while inserting application");
			} 			
		}		
		return applicationId;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	getAllScheduledPrograms()
	 - Input Parameters	:	No input parameters
	 - Return Type		:	ArrayList<ProgramScheduled>
	 - Author			:	CAPGEMINI
	 - Creation Date	:	12/09/2019
	 - Description		:	retrieving details of all scheduled programs from database
	 * @throws UASException 
	 ********************************************************************************************************/
	@Override
	public ArrayList<ProgramScheduled> getAllScheduledPrograms() throws UASException {		
		ArrayList<ProgramScheduled> programScheduledList = new ArrayList<ProgramScheduled>();
		PreparedStatement pstmt = null;
		
		logger.info("Function for fetching all schduled program stated ");
		     try {
		    	con= DBUtil.getConnection();
		    	logger.info("Connection established to the Database");
				pstmt = con.prepareStatement(ApplicationQMapper.SELECT_ALL_PS);
				ResultSet rs = pstmt.executeQuery();
				
				while(rs.next()){
					programScheduledList.add(new ProgramScheduled(rs.getString(1),rs.getString(2),rs.getString(3),rs.getDate(4),rs.getDate(5),rs.getInt(6)));
				}
			} 
		     catch (SQLException | IOException e) {
		    	 logger.fatal("Exception occured while getting scheduled program ");
				 throw new UASException("Exception occured while getting scheduled program");
			} 
		    logger.info("Function for fetching all schduled program successful "); 
		return programScheduledList;
	}

	/*******************************************************************************************************
	 - Function Name	:	applicationStatus()
	 - Input Parameters	:	ID of Applicant
	 - Return Type		:	String
	 - Author			:	CAPGEMINI
	 - Creation Date	:	21/09/2019
	 - Description		:	Checking status of applicant from database
	 * @throws UASException 
	 ********************************************************************************************************/
	@Override
	public String applicationStatus(int ID) throws UASException {		
		String status = null;
		Date date = null;
		PreparedStatement pstmt = null;				
		try {
			con= DBUtil.getConnection();
			logger.info("Connection established to the Database");
			pstmt = con.prepareStatement(ApplicationQMapper.STATUS_usingID);
			pstmt.setInt(1,ID);
			ResultSet resultset = pstmt.executeQuery();
			if(resultset.next())
			{
				status = resultset.getString(1);
				date = resultset.getDate(2);
				logger.info("Function for fetching application status successful ");
			}	
			if(date==null)
			{
				return status+" Interview Date: Not scheduled";
			}
		} 
		catch (SQLException | IOException sqlException) {
			logger.warn("Exception occured while getting scheduled program");
			throw new UASException("Exception occured while getting scheduled program");
		} 		
		return status + " " +" Interview Date:" + date;
	}

	/*******************************************************************************************************
	 - Function Name	:	getScheduledProgramsId()
	 - Input Parameters	:	No input parameters
	 - Return Type		:	ArrayList<String>
	 - Author			:	CAPGEMINI
	 - Creation Date	:	12/09/2019
	 - Description		:	retrieving scheduled program id from database
	 * @throws UASException 
	 ********************************************************************************************************/
	@Override
	public ArrayList<String> getScheduledProgramId() throws UASException {
		ArrayList<String> list = new ArrayList<String>();
		try{
			con= DBUtil.getConnection();
			logger.info("Connection established to the Database");
			PreparedStatement pst = con.prepareStatement(ApplicationQMapper.SCH_PROGRAM_ID);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				list.add(rs.getString("SCHEDULED_PROGRAM_ID"));
			}	
		}		
		catch(Exception e){
			logger.warn("No Scheduled Programs Found");
			throw new UASException("No Programs Found");
		}
		return list;
	}
}