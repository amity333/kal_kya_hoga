package com.cg.dto;

public class Participant {

	private String rollNo;
	private String emailId;
	private int applicationId;
	private String scheduleProgId;
		
	public Participant() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Participant(String rollNo, String emailId, int applicationId,
			String scheduleProgId) {
		super();
		this.rollNo = rollNo;
		this.emailId = emailId;
		this.applicationId = applicationId;
		this.scheduleProgId = scheduleProgId;
	}

	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public String getScheduleProgId() {
		return scheduleProgId;
	}

	public void setScheduleProgId(String scheduleProgId) {
		this.scheduleProgId = scheduleProgId;
	}
	
	
	
}
