package com.cg.service;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.Exception.UASException;
import com.cg.dto.Application;
import com.cg.dto.ProgramOffered;
import com.cg.dto.ProgramScheduled;

public interface AdminService {

	boolean checkLogin(String loginId, String password);

	void addProgram(ProgramOffered obj) throws UASException;

	boolean deleteProgram(String programName) throws UASException ;

	void scheduleProgram(ProgramScheduled obj);

	ArrayList<ProgramScheduled> getScheduledProgram(Date startDate, Date endDate);
	
	public boolean isValidScheduledName(String progName) throws UASException ;

	ArrayList<Application> getStatus(String status);

	ArrayList<String> getProgramsOffered();

	ArrayList<ProgramOffered> getProgramsOfferedDetails() throws UASException;
	
	public boolean isValidName(String progName) throws UASException;
	
	public boolean isValidDescription(String desc) throws UASException;
	
	public boolean isValidEligibility(String eligibility) throws UASException;
	
	public boolean isValidDuration(int duration) throws UASException;
	
	public boolean isValidDegree(String degree) throws UASException;
	
	public boolean isValidLocation(String location) throws UASException;
	
	public boolean isValidDate(ProgramScheduled program);
	
	
}
