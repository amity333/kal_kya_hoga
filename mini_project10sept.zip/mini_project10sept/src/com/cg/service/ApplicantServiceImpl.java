package com.cg.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.Exception.UASException;
import com.cg.dao.ApplicationDAOImpl;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;
import com.cg.util.MyStringDateUtil;

public class ApplicantServiceImpl implements ApplicantService{
	
	ApplicationDAOImpl dao=new ApplicationDAOImpl();

	@Override
	public List<ProgramScheduled> getAllScheduledPrograms() throws UASException {
		return dao.getAllScheduledPrograms();
	}

	@Override
	public int addApplication(Application applicant) throws UASException {
			if(applicant.getGoals().length()>20)
				throw new UASException("Goals must be less than 20 characters.");
		return dao.addApplication(applicant);
	}

	@Override
	public String applicationStatus(int ID) throws UASException {
		return dao.applicationStatus(ID);
	}

	@Override
	public ArrayList<String> getScheduledProgramId() throws UASException {
		// TODO Auto-generated method stub
		return dao.getScheduledProgramId();
	}

//	@Override
//	public boolean validateApplicant(Application applicant) 
//	{
//		boolean result = false;
//		List<String> validationErrors = new ArrayList<String>();
//
//		//Validating applicant name
//		if(!(isValidName(applicant.getFullName()))) 
//		{
//			validationErrors.add("\n Applicant Name Should Be In Alphabets and minimum 3 characters long ! ");
//		}
//		//Validating DOB
//		if(!(isValidDob(applicant.getDateOfBirth())))
//		{
//			validationErrors.add("\n Date of Birth Should be in DD/MM/YYYY format");
//		}
//		
//		//Validating Qualification
//		if(!(isValidQualification(applicant.getHighestQualification()))) 
//		{
//			validationErrors.add("\n Invalid Qualification");
//		}
//		
//		//Validating Marks
//		if(!(isValidMarks(applicant.getMarksObtained())))
//		{
//			validationErrors.add("\n Marks Should be a positive Number <= 100" );
//		}
//		
//		//Validating Goals
//		if(!(isValidGoals(applicant.getGoals())))
//{
//			validationErrors.add("\n Invalid Goals");
//		}
//				
//		//Validating Email ID
//		if(!(isValidEmailId(applicant.getEmailId())))
//		{
//			validationErrors.add("\n Invalid Email-Id");
//		}
//		
//		//Validating Id
//		if(!(isValidScheduleProgId(applicant.getScheduledProgramId()))) 
//		{
//			validationErrors.add("\n Invalid Program ID");
//		}
//				
//		return result;
//		
//	}
	public  boolean isValidName(String applicantName)
	{
		//Pattern namePattern=Pattern.compile("^[a-zA-Z\\s]*$");
		//Matcher nameMatcher=namePattern.matcher(applicantName);
		//return nameMatcher.matches();
		if(applicantName.matches("[A-Z]{1}[a-zA-Z ]{2,19}"))
		{
			return true;
		}
		else
			return false;
	}
	
	public  boolean isValidDob(String  localDate)
	{
		String regex = "^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4}$"; 
		Pattern pattern = Pattern.compile(regex); 
		Matcher matcher = pattern.matcher((CharSequence)localDate); 
		if(matcher.matches())
		{
			LocalDate date=MyStringDateUtil.fromStringToLocalDate(localDate);
			LocalDate date2=LocalDate.now();
			Period diff=Period.between(date, date2);
			if(diff.getYears()>15)
				return true;
			else
				return false;
		}
		return false;
	}
	
	public  boolean isValidQualification(String qualification)
	{
		
		return (qualification.length() > 1);
	}
	
	public  boolean isValidGoals(String goals)
	{
		String regex = "[a-zA-Z] {3,}"; 
		Pattern pattern = Pattern.compile(regex); 
		Matcher matcher = pattern.matcher((CharSequence)goals); 
		//return matcher.matches(); 
		return (matcher.matches() && goals.length() > 2);
	}
	
	public  boolean isValidMarks(int marks)
	{
		return (marks>=0 && marks<=100);
	}
	
	public  boolean isValidEmailId(String email) {
		Pattern namePattern=Pattern.compile("[a-zA-Z][a-zA-Z0-9-.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+");
		Matcher nameMatcher=namePattern.matcher(email);
		return nameMatcher.matches();
	}
	
	public boolean isValidScheduleProgId(String scheduleProgId) throws UASException 
    {		
		List<String> programIdList = getScheduledProgramId();
		//System.out.println(programIdList);
		boolean check = false;
		for (String programId : programIdList) {
			//System.out.println("\nChecking.." +programId);
			if ((programId.toUpperCase()).equals(scheduleProgId))
			{
				check = true;
			}
		}
		return check;
	}

}
